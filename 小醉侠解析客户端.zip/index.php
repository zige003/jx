<?php
require_once 'config.php';

$url = "player.php?url=".getUrl();
?>
<!DOCTYPE html>
<html lang='zh-CN'>

<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'>
    <meta name='renderer' content='webkit|ie-comp|ie-stand'>
    <meta name='applicable-device' content='pc,mobile'>
    <meta name='MobileOptimized' content='width' />
    <meta name='HandheldFriendly' content='true' />
    <link rel="icon" href="<?php echo $user['ico']; ?>">
    <title><?php echo $user['title']; ?></title>
    <style>
        body,
        html,
        #WANG {
            padding: 0;
            margin: 0;
            height: 100%;
            width: 100%;
        }
    </style>
</head>

<body style='overflow-y:hidden;'>
    <div style='width: 100%; height: 100%;'>
        <iframe id='WANG' scrolling='yes' allowtransparency='true' allowfullscreen='true' frameborder='0' src='<?php echo $url ?>' width='100%' height='100%'></iframe>
    </div>
</body>

</html>