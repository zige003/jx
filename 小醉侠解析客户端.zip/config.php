<?php
/*
* User setting file;
* @author miao.party LLQ
* @version 1.0
* @date 2021-05-25
* @不懂千万别乱修改代码
*/
    require_once 'class.php';
    header("Access-Control-Allow-Origin: *");

    $cacheTime = 300;  //  缓存时间 单位 秒
    $async     = false;  // false同步 true异步
    $secret    = true; //  是否开启M3U8防盗
    $secretKey = "good"; //加密密钥自定义

    $specialapi = array( //专线
         //   "",  //  域名|接口
    );      
    $api        = array(  //此处填写API

            'www.json.com',  //此处www.xzxjx.xyz后台获取 影视API连接 复制粘贴替换即可

    );
    $originarr  = array(   // 留空允许所有域名
      //  '',  //设置允许访问的域名  举例  一行一个  （设置你的播放器域名) 不需要http:// 或https://
    );  
     
    $user       = array(
        "title"       => "小醉侠蓝光影视解析", //网站标题
        "ico"         => "", //网站图标ico
        "logo"        => "",  //右上角logo
        "img"         => "", //封面图
        "button"      => "xzxjx.xyz,//www.xzxjx.xyz", //右键button  用,隔开网址
        "startAD"     => "", //广告类型（pic/video, 内容外链, 跳转链接, pic广告时间 秒）
        "danmuon"     => 1,  //是否开启弹幕
        "danmuku"     => "//dmku.byteamone.cn/dmku/",
        "pauseAD"     => "", //暂停广告   格式 ：图片链接,图片跳转链接
        "themeColor"  => '#00FFFF', //主题颜色
        "forbidden"   => "此网站未授权播放",
        "bad"         => "<img src='http://xzxjx.xyz/bz.jpg' width='50%'><br/>视频链接解析错误,请联系管理员"
    );
    

    
    $button = explode(",",$user['button']);
    
 
    
/* 
* End of File 
* @path ./config.php
*/
